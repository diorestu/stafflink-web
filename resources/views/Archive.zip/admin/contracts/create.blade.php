@extends('admin.layout')

@section('page-title', 'Create Contract')
@section('title', 'Create Contract')

@section('content')
    <style>
        .contract-compact label { margin-bottom: 0.35rem !important; font-size: 0.8rem; }
        .contract-compact input,
        .contract-compact select,
        .contract-compact textarea { padding: 0.5rem 0.75rem !important; font-size: 0.85rem; }
        .section-card {
            border: 1px solid #e5e7eb;
            border-radius: 0.75rem;
            background: #ffffff;
            padding: 1rem;
        }
        .mini-editor {
            min-height: 120px;
            border: 1px solid #e5e7eb;
            border-radius: 0.5rem;
            padding: 0.75rem;
            background: #ffffff;
            overflow-wrap: anywhere;
        }
    </style>
    <div class="max-w-4xl">
        <div class="bg-white rounded-xl shadow-sm border border-gray-100">
            <div class="px-5 py-4 border-b bg-gray-50/60 rounded-t-xl">
                <h3 class="text-lg font-semibold text-gray-900">Create Employment Contract from Template</h3>
                <p class="text-sm text-gray-500 mt-1">Template mengikuti dokumen kontrak kerja, Isi data pelengkap, lalu unduh PDF.</p>
            </div>

            <form action="{{ route('admin.contracts.generate') }}" method="POST" class="contract-compact p-5 space-y-5">
                @csrf
                <div class="section-card grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label for="template" class="block text-sm font-medium text-gray-700 mb-2">Template *</label>
                        <select id="template" name="template" required
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent bg-white">
                            @foreach ($templates as $value => $label)
                                <option value="{{ $value }}" {{ old('template', 'fixed_term_pkwt') === $value ? 'selected' : '' }}>{{ $label }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div>
                        <label for="contract_number" class="block text-sm font-medium text-gray-700 mb-2">Contract Number</label>
                        <input type="text" id="contract_number" name="contract_number" value="{{ old('contract_number') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="Contoh: SL-EMP-2026-001">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                        <label for="agreement_date" class="block text-sm font-medium text-gray-700 mb-2">Agreement Date *</label>
                        <input type="date" id="agreement_date" name="agreement_date" required value="{{ old('agreement_date') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="start_date" class="block text-sm font-medium text-gray-700 mb-2">Start Date *</label>
                        <input type="date" id="start_date" name="start_date" required value="{{ old('start_date') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="end_date" class="block text-sm font-medium text-gray-700 mb-2">End Date *</label>
                        <input type="date" id="end_date" name="end_date" required value="{{ old('end_date') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label for="company_name" class="block text-sm font-medium text-gray-700 mb-2">Company Name *</label>
                        <input type="text" id="company_name" name="company_name" required value="{{ old('company_name', 'PT Staff Link Solutions') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="company_address" class="block text-sm font-medium text-gray-700 mb-2">Company Registered Address *</label>
                        <input type="text" id="company_address" name="company_address" required value="{{ old('company_address', 'Jl. Drupadi 1, No. 20, Seminyak') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="first_party_name" class="block text-sm font-medium text-gray-700 mb-2">First Party Signer Name *</label>
                        <input type="text" id="first_party_name" name="first_party_name" required value="{{ old('first_party_name', 'PT Staff Link Solutions') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="first_party_position" class="block text-sm font-medium text-gray-700 mb-2">First Party Position *</label>
                        <input type="text" id="first_party_position" name="first_party_position" required value="{{ old('first_party_position', 'Director') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div class="md:col-span-2">
                        <label for="first_party_address" class="block text-sm font-medium text-gray-700 mb-2">First Party Address *</label>
                        <input type="text" id="first_party_address" name="first_party_address" required value="{{ old('first_party_address', 'Seminyak, Bali') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-2 gap-3">
                    <div>
                        <label for="employer_name" class="block text-sm font-medium text-gray-700 mb-2">Employer / First Party *</label>
                        <input type="text" id="employer_name" name="employer_name" required value="{{ old('employer_name', 'PT Staff Link Solutions') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="position_title" class="block text-sm font-medium text-gray-700 mb-2">Position Title *</label>
                        <input type="text" id="position_title" name="position_title" required value="{{ old('position_title') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="Contoh: Nanny / Light Gauge Steel Worker">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-12 gap-3">
                    <div class="md:col-span-2">
                        <label for="employee_title" class="block text-sm font-medium text-gray-700 mb-2">Employee Title *</label>
                        <select id="employee_title" name="employee_title" required
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent bg-white">
                            @foreach (['Mr.', 'Mrs.', 'Ms.'] as $title)
                                <option value="{{ $title }}" {{ old('employee_title', 'Ms.') === $title ? 'selected' : '' }}>{{ $title }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="md:col-span-5">
                        <label for="employee_name" class="block text-sm font-medium text-gray-700 mb-2">Employee Name *</label>
                        <input type="text" id="employee_name" name="employee_name" required value="{{ old('employee_name') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div class="md:col-span-5">
                        <label for="employee_id_number" class="block text-sm font-medium text-gray-700 mb-2">ID Number (KTP/SIM/Passport)</label>
                        <input type="text" id="employee_id_number" name="employee_id_number" value="{{ old('employee_id_number') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div class="md:col-span-4">
                        <label for="employee_birth_info" class="block text-sm font-medium text-gray-700 mb-2">Place & Date of Birth</label>
                        <input type="text" id="employee_birth_info" name="employee_birth_info" value="{{ old('employee_birth_info') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div class="md:col-span-4">
                        <label for="employee_gender" class="block text-sm font-medium text-gray-700 mb-2">Gender</label>
                        <select id="employee_gender" name="employee_gender"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent bg-white">
                            <option value="">Select gender</option>
                            @foreach (['Male', 'Female', 'Other'] as $gender)
                                <option value="{{ $gender }}" {{ old('employee_gender') === $gender ? 'selected' : '' }}>{{ $gender }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="md:col-span-4">
                        <label for="employee_religion" class="block text-sm font-medium text-gray-700 mb-2">Religion</label>
                        <select id="employee_religion" name="employee_religion"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent bg-white">
                            <option value="">Select religion</option>
                            @foreach (['Islam', 'Christian', 'Catholic', 'Hindu', 'Buddhist', 'Confucian', 'Other'] as $religion)
                                <option value="{{ $religion }}" {{ old('employee_religion') === $religion ? 'selected' : '' }}>{{ $religion }}</option>
                            @endforeach
                        </select>
                    </div>
                    <div class="md:col-span-4">
                        <label for="employee_phone" class="block text-sm font-medium text-gray-700 mb-2">Phone Number</label>
                        <input type="text" id="employee_phone" name="employee_phone" value="{{ old('employee_phone') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div class="md:col-span-8">
                        <label for="employee_address" class="block text-sm font-medium text-gray-700 mb-2">Employee Address</label>
                        <input type="text" id="employee_address" name="employee_address" value="{{ old('employee_address') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-4 gap-3">
                    <div>
                        <label for="employment_basis" class="block text-sm font-medium text-gray-700 mb-2">Employment Basis *</label>
                        <input type="text" id="employment_basis" name="employment_basis" required value="{{ old('employment_basis', 'Full-time Fixed Term') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="probation_months" class="block text-sm font-medium text-gray-700 mb-2">Probation (Months) *</label>
                        <input type="number" id="probation_months" name="probation_months" min="0" max="12" required value="{{ old('probation_months', 3) }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="pay_day" class="block text-sm font-medium text-gray-700 mb-2">Salary Pay Day *</label>
                        <input type="number" id="pay_day" name="pay_day" min="1" max="31" required value="{{ old('pay_day', 7) }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="notice_period_days" class="block text-sm font-medium text-gray-700 mb-2">Notice Period (Days) *</label>
                        <input type="number" id="notice_period_days" name="notice_period_days" min="1" max="180" required value="{{ old('notice_period_days', 30) }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-5 gap-3">
                    <div>
                        <label for="working_hours_per_day" class="block text-sm font-medium text-gray-700 mb-2">Working Hours / Day *</label>
                        <input type="text" id="working_hours_per_day" name="working_hours_per_day" required value="{{ old('working_hours_per_day', '7 hours 30 minutes') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="working_days_per_week" class="block text-sm font-medium text-gray-700 mb-2">Working Days / Week *</label>
                        <input type="number" id="working_days_per_week" name="working_days_per_week" min="1" max="7" required value="{{ old('working_days_per_week', 6) }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="work_start_time" class="block text-sm font-medium text-gray-700 mb-2">Work Start Time *</label>
                        <input type="text" id="work_start_time" name="work_start_time" required value="{{ old('work_start_time', '08.30 WITA') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="work_end_time" class="block text-sm font-medium text-gray-700 mb-2">Work End Time *</label>
                        <input type="text" id="work_end_time" name="work_end_time" required value="{{ old('work_end_time', '17.00 WITA') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="salary_total" class="block text-sm font-medium text-gray-700 mb-2">Total Monthly Salary (IDR) *</label>
                        <input type="text" id="salary_total" name="salary_total" required value="{{ old('salary_total') }}"
                            data-currency="idr"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="5.500.000">
                    </div>
                    <div>
                        <label for="salary_base" class="block text-sm font-medium text-gray-700 mb-2">Base Salary (IDR)</label>
                        <input type="text" id="salary_base" name="salary_base" value="{{ old('salary_base') }}"
                            data-currency="idr"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="3.800.000">
                    </div>
                    <div>
                        <label for="salary_allowance" class="block text-sm font-medium text-gray-700 mb-2">Allowance (IDR)</label>
                        <input type="text" id="salary_allowance" name="salary_allowance" value="{{ old('salary_allowance') }}"
                            data-currency="idr"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="400.000">
                    </div>
                    <div>
                        <label for="food_allowance" class="block text-sm font-medium text-gray-700 mb-2">Food Allowance (IDR)</label>
                        <input type="text" id="food_allowance" name="food_allowance" value="{{ old('food_allowance') }}"
                            data-currency="idr"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                            placeholder="200.000">
                    </div>
                </div>

                <div class="section-card">
                    <label class="block text-sm font-medium text-gray-700 mb-2">Role Highlights (Short Bullet List)</label>
                    <div class="flex items-center gap-2 mb-2">
                        <button type="button" id="role-bullet-btn" class="px-3 py-1.5 rounded-lg border border-gray-300 text-xs text-gray-700 hover:bg-gray-50">Bullet List</button>
                        <button type="button" id="role-clear-format-btn" class="px-3 py-1.5 rounded-lg border border-gray-300 text-xs text-gray-700 hover:bg-gray-50">Clear Format</button>
                    </div>
                    <div id="role_brief_points_editor" class="mini-editor text-sm" contenteditable="true"></div>
                    <input type="hidden" id="role_brief_points" name="role_brief_points" value="{{ old('role_brief_points') }}">
                    <p class="mt-2 text-xs text-gray-500">Bagian ini terpisah dari Responsibilities library. Isi kalimat singkat, bisa ketik langsung atau paste bullet list.</p>
                </div>

                <div class="section-card">
                    <div class="flex items-center justify-between gap-3 mb-2">
                        <label class="block text-sm font-medium text-gray-700">Responsibilities</label>
                        <button type="button" id="open-responsibility-modal"
                            class="inline-flex items-center justify-center rounded-full bg-[#287854] text-white w-8 h-8 text-lg leading-none hover:bg-[#1f5f46]"
                            aria-label="Add responsibility">+</button>
                    </div>
                    <input type="hidden" id="responsibilities" name="responsibilities" value="{{ old('responsibilities') }}">
                    <div id="responsibility-list" class="space-y-3 rounded-lg border border-gray-200 bg-gray-50 p-4"></div>
                    <p class="mt-2 text-xs text-gray-500">Tick only the responsibilities you want to include in the contract.</p>
                </div>

                <div id="responsibility-modal" class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 p-4">
                    <div class="w-full max-w-lg rounded-xl bg-white shadow-xl border border-gray-200">
                        <div class="px-6 py-4 border-b">
                            <h4 class="text-lg font-semibold text-gray-900">Create New Responsibility</h4>
                        </div>
                        <div class="p-6 space-y-4">
                            <div>
                                <label for="new_responsibility_title" class="block text-sm font-medium text-gray-700 mb-2">Title</label>
                                <input type="text" id="new_responsibility_title"
                                    class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                                    placeholder="e.g. Vendor Reconciliation">
                            </div>
                            <div>
                                <label for="new_responsibility_description" class="block text-sm font-medium text-gray-700 mb-2">Description</label>
                                <textarea id="new_responsibility_description" rows="4"
                                    class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent"
                                    placeholder="Write responsibility description"></textarea>
                            </div>
                        </div>
                        <div class="px-6 py-4 border-t flex items-center justify-end gap-3">
                            <button type="button" id="cancel-responsibility-modal" class="px-4 py-2 rounded-lg border border-gray-300 text-gray-700 hover:bg-gray-50">Cancel</button>
                            <button type="button" id="save-responsibility-modal" class="px-4 py-2 rounded-lg bg-[#287854] text-white hover:bg-[#1f5f46]">Add Responsibility</button>
                        </div>
                    </div>
                </div>

                <div class="section-card">
                    <label for="additional_terms" class="block text-sm font-medium text-gray-700 mb-2">Additional Terms</label>
                    <textarea id="additional_terms" name="additional_terms" rows="4"
                        class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">{{ old('additional_terms') }}</textarea>
                </div>

                <div class="section-card grid grid-cols-1 md:grid-cols-3 gap-3">
                    <div>
                        <label for="governing_law" class="block text-sm font-medium text-gray-700 mb-2">Governing Law</label>
                        <input type="text" id="governing_law" name="governing_law" value="{{ old('governing_law', 'Republic of Indonesia') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="sign_employer_name" class="block text-sm font-medium text-gray-700 mb-2">Employer Signatory *</label>
                        <input type="text" id="sign_employer_name" name="sign_employer_name" required value="{{ old('sign_employer_name') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                    <div>
                        <label for="sign_employee_name" class="block text-sm font-medium text-gray-700 mb-2">Employee Signatory *</label>
                        <input type="text" id="sign_employee_name" name="sign_employee_name" required value="{{ old('sign_employee_name') }}"
                            class="w-full px-4 py-2.5 border border-gray-200 rounded-lg focus:ring-2 focus:ring-[#287854] focus:border-transparent">
                    </div>
                </div>

                @if ($errors->any())
                    <div class="rounded-lg border border-red-200 bg-red-50 px-4 py-3 text-sm text-red-700">
                        <ul class="list-disc list-inside space-y-1">
                            @foreach ($errors->all() as $error)
                                <li>{{ $error }}</li>
                            @endforeach
                        </ul>
                    </div>
                @endif

                <div class="flex items-center justify-end pt-6 border-t">
                    <button type="submit" class="bg-[#287854] hover:bg-[#1f5f46] text-white px-6 py-2.5 rounded-lg font-medium">
                        Generate & Download PDF
                    </button>
                </div>
            </form>
        </div>
    </div>

    <script>
        (() => {
            const listEl = document.getElementById('responsibility-list');
            const hiddenInput = document.getElementById('responsibilities');
            const modal = document.getElementById('responsibility-modal');
            const openModalBtn = document.getElementById('open-responsibility-modal');
            const cancelModalBtn = document.getElementById('cancel-responsibility-modal');
            const saveModalBtn = document.getElementById('save-responsibility-modal');
            const newTitleInput = document.getElementById('new_responsibility_title');
            const newDescInput = document.getElementById('new_responsibility_description');
            const roleBriefEditor = document.getElementById('role_brief_points_editor');
            const roleBriefInput = document.getElementById('role_brief_points');
            const roleBulletBtn = document.getElementById('role-bullet-btn');
            const roleClearFormatBtn = document.getElementById('role-clear-format-btn');

            let responsibilities = @json($responsibilityLibrary ?? []);
            const oldRaw = @json(old('responsibilities'));

            const checkedMap = new Map();

            const parseOldResponsibilities = () => {
                if (!oldRaw) return;
                const lines = oldRaw.split(/\r\n|\r|\n/).map((line) => line.trim()).filter(Boolean);
                lines.forEach((line) => {
                    const parts = line.split(':');
                    const title = (parts.shift() || '').trim();
                    const description = parts.join(':').trim();
                    if (!title) return;

                    const idx = responsibilities.findIndex((item) => item.title.toLowerCase() === title.toLowerCase());
                    if (idx === -1) {
                        responsibilities.push({ title, description });
                        checkedMap.set(responsibilities.length - 1, true);
                    } else {
                        checkedMap.set(idx, true);
                    }
                });
            };

            const defaultAllChecked = () => {
                responsibilities.forEach((_, index) => checkedMap.set(index, true));
            };

            const syncHiddenInput = () => {
                const selected = responsibilities
                    .filter((_, index) => checkedMap.get(index))
                    .map((item) => `${item.title}: ${item.description}`);
                hiddenInput.value = selected.join('\n');
            };

            const renderList = () => {
                listEl.innerHTML = '';
                responsibilities.forEach((item, index) => {
                    const wrapper = document.createElement('label');
                    wrapper.className = 'flex items-start gap-3 rounded-lg border border-gray-200 bg-white px-4 py-3';

                    const checkbox = document.createElement('input');
                    checkbox.type = 'checkbox';
                    checkbox.className = 'mt-1 h-4 w-4 rounded border-gray-300 text-[#287854] focus:ring-[#287854]';
                    checkbox.checked = Boolean(checkedMap.get(index));
                    checkbox.addEventListener('change', () => {
                        checkedMap.set(index, checkbox.checked);
                        syncHiddenInput();
                    });

                    const textWrap = document.createElement('div');
                    textWrap.className = 'text-sm';
                    const titleEl = document.createElement('p');
                    titleEl.className = 'font-semibold text-gray-900';
                    titleEl.textContent = item.title;
                    const descEl = document.createElement('p');
                    descEl.className = 'text-gray-600 mt-0.5';
                    descEl.textContent = item.description || '-';
                    textWrap.appendChild(titleEl);
                    textWrap.appendChild(descEl);

                    wrapper.appendChild(checkbox);
                    wrapper.appendChild(textWrap);
                    listEl.appendChild(wrapper);
                });
                syncHiddenInput();
            };

            const openModal = () => {
                modal.classList.remove('hidden');
                modal.classList.add('flex');
                newTitleInput.focus();
            };

            const closeModal = () => {
                modal.classList.add('hidden');
                modal.classList.remove('flex');
                newTitleInput.value = '';
                newDescInput.value = '';
            };

            openModalBtn.addEventListener('click', openModal);
            cancelModalBtn.addEventListener('click', closeModal);
            modal.addEventListener('click', (event) => {
                if (event.target === modal) closeModal();
            });

            saveModalBtn.addEventListener('click', () => {
                const title = newTitleInput.value.trim();
                const description = newDescInput.value.trim();
                if (!title) return;

                responsibilities.push({ title, description });
                checkedMap.set(responsibilities.length - 1, true);
                renderList();
                closeModal();
            });

            const setEditorFromHidden = () => {
                const value = String(roleBriefInput.value || '').trim();
                if (!value) {
                    roleBriefEditor.innerHTML = '<ul><li></li></ul>';
                    return;
                }

                if (value.includes('<')) {
                    roleBriefEditor.innerHTML = value;
                    return;
                }

                const lines = value.split(/\r\n|\r|\n|,|;/).map((line) => line.trim()).filter(Boolean);
                roleBriefEditor.innerHTML = lines.length > 0
                    ? `<ul>${lines.map((line) => `<li>${line}</li>`).join('')}</ul>`
                    : value;
            };

            const syncRoleBriefInput = () => {
                roleBriefInput.value = roleBriefEditor.innerHTML.trim();
            };

            roleBriefEditor.addEventListener('input', syncRoleBriefInput);
            roleBulletBtn.addEventListener('click', () => {
                roleBriefEditor.focus();
                document.execCommand('insertUnorderedList');
                syncRoleBriefInput();
            });
            roleClearFormatBtn.addEventListener('click', () => {
                const text = roleBriefEditor.innerText || '';
                roleBriefEditor.textContent = text;
                syncRoleBriefInput();
            });

            setEditorFromHidden();
            syncRoleBriefInput();

            parseOldResponsibilities();
            if (!oldRaw) defaultAllChecked();
            renderList();

            const form = document.querySelector('form[action="{{ route('admin.contracts.generate') }}"]');
            if (form) {
                form.addEventListener('submit', () => {
                    syncRoleBriefInput();
                });
            }

            const formatCurrency = (value) => {
                const digits = String(value || '').replace(/[^\d]/g, '');
                if (!digits) return '';
                return new Intl.NumberFormat('id-ID').format(Number(digits));
            };

            const currencyInputs = document.querySelectorAll('input[data-currency=\"idr\"]');
            currencyInputs.forEach((input) => {
                input.value = formatCurrency(input.value);
                input.addEventListener('input', () => {
                    input.value = formatCurrency(input.value);
                });
            });
        })();
    </script>
@endsection
