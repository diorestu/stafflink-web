<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="px-6 pb-20">
    <div class="mx-auto max-w-6xl">
        <div class="rounded-[32px] bg-[#1f5f46] px-8 py-12 text-white shadow-[0_20px_60px_rgba(31,95,70,0.2)]"
            data-aos="fade-up">
            <div class="flex flex-wrap items-center justify-between gap-6">
                <div>
                    <h3 class="text-3xl text-[#d6c18a]"><?php echo e($content['title'] ?? 'Get Started'); ?></h3>
                    <p class="mt-2 text-sm text-white/80"><?php echo e($content['subtitle'] ?? "We're here to help."); ?></p>
                </div>
                <button
                    class="rounded-full bg-[#b28b2e] px-5 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-[#9b7829]"><?php echo e($content['button_text'] ?? "Let's Talk"); ?></button>
            </div>
            <div class="mt-8 grid gap-6 lg:grid-cols-3">
                <?php
                    $ctaIcons = [
                        '<path d="M8 9h8" /><path d="M8 13h5" /><path d="M4 4h16v12H8l-4 4z" />',
                        '<path d="M5 4h4l2 5-2 2a12 12 0 0 0 6 6l2-2 5 2v4a2 2 0 0 1-2 2 16 16 0 0 1-14-14 2 2 0 0 1 2-2" />',
                        '<circle cx="9" cy="7" r="3" /><circle cx="17" cy="7" r="3" /><path d="M2 20a7 7 0 0 1 14 0" /><path d="M10 20a7 7 0 0 1 14 0" />',
                    ];
                ?>
                <?php $__currentLoopData = $content['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-2xl bg-white/15 px-6 py-6 text-white backdrop-blur-lg ring-1 ring-white/30 shadow-[0_18px_40px_rgba(31,95,70,0.18)]"
                        data-aos="fade-up" data-aos-delay="<?php echo e(($i + 1) * 100); ?>">
                        <div class="flex h-9 w-9 items-center justify-center rounded-full bg-white/30 text-white">
                            <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                                stroke-width="1.5">
                                <?php echo $ctaIcons[$i] ?? $ctaIcons[0]; ?>

                            </svg>
                        </div>
                        <h3 class="mt-4 text-base font-semibold"><?php echo e($card['title'] ?? ''); ?></h3>
                        <p class="mt-2 text-sm text-white/80"><?php echo e($card['description'] ?? ''); ?></p>
                        <?php if(($card['contact_type'] ?? '') === 'email'): ?>
                            <a href="mailto:<?php echo e($card['contact'] ?? ''); ?>"
                                class="mt-4 inline-flex text-sm font-semibold text-white"><?php echo e($card['contact'] ?? ''); ?></a>
                        <?php elseif(($card['contact_type'] ?? '') === 'hours'): ?>
                            <p class="mt-4 text-sm font-semibold text-white"><?php echo e($card['contact'] ?? ''); ?></p>
                        <?php endif; ?>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>
</section>
<?php /**PATH /Users/widawatimanuaba/Documents/Dio's Works/stafflink_web/resources/views/components/cta.blade.php ENDPATH**/ ?>