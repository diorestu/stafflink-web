<?php $__env->startSection('title', 'Edit ' . $label); ?>
<?php $__env->startSection('heading'); ?>
    <div class="flex items-center gap-3">
        <a href="<?php echo e(route('admin.dashboard')); ?>" class="text-[#6b6b66] transition hover:text-[#2e2e2e]">
            <svg class="h-5 w-5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                <path d="M19 12H5" />
                <path d="M12 19l-7-7 7-7" />
            </svg>
        </a>
        Edit: <?php echo e($label); ?>

    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <form method="POST" action="<?php echo e(route('admin.sections.update', $pageSection->section)); ?>" class="mx-auto max-w-4xl">
        <?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>

        <div class="space-y-6">
            <?php $content = $pageSection->content; ?>

            <?php $__currentLoopData = $content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $value): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(is_string($value)): ?>
                    
                    <div class="rounded-2xl bg-white p-6 shadow-sm">
                        <label
                            class="mb-2 block text-sm font-semibold text-[#2e2e2e]"><?php echo e(ucwords(str_replace('_', ' ', $key))); ?></label>
                        <?php if(strlen($value) > 100): ?>
                            <textarea name="content[<?php echo e($key); ?>]" rows="3"
                                class="w-full rounded-xl border border-[#d7d9e4] px-4 py-3 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20"><?php echo e($value); ?></textarea>
                        <?php else: ?>
                            <input type="text" name="content[<?php echo e($key); ?>]" value="<?php echo e($value); ?>"
                                class="w-full rounded-xl border border-[#d7d9e4] px-4 py-3 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20" />
                        <?php endif; ?>
                    </div>
                <?php elseif(is_array($value)): ?>
                    
                    <div class="rounded-2xl bg-white p-6 shadow-sm">
                        <h3 class="mb-4 text-sm font-semibold uppercase tracking-wider text-[#b28b2e]">
                            <?php echo e(ucwords(str_replace('_', ' ', $key))); ?></h3>
                        <div class="space-y-4">
                            <?php $__currentLoopData = $value; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if(is_array($item)): ?>
                                    <div class="rounded-xl border border-[#e6e8ed] p-5">
                                        <div class="mb-3 flex items-center justify-between">
                                            <span class="text-xs font-semibold text-[#6b6b66]">#<?php echo e($i + 1); ?></span>
                                        </div>
                                        <div class="grid gap-4 sm:grid-cols-2">
                                            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subKey => $subValue): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if(is_string($subValue)): ?>
                                                    <div class="<?php echo e(strlen($subValue) > 80 ? 'sm:col-span-2' : ''); ?>">
                                                        <label
                                                            class="mb-1.5 block text-xs font-medium text-[#6b6b66]"><?php echo e(ucwords(str_replace('_', ' ', $subKey))); ?></label>
                                                        <?php if(strlen($subValue) > 80): ?>
                                                            <textarea name="content[<?php echo e($key); ?>][<?php echo e($i); ?>][<?php echo e($subKey); ?>]" rows="2"
                                                                class="w-full rounded-lg border border-[#d7d9e4] px-3 py-2 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20"><?php echo e($subValue); ?></textarea>
                                                        <?php else: ?>
                                                            <input type="text"
                                                                name="content[<?php echo e($key); ?>][<?php echo e($i); ?>][<?php echo e($subKey); ?>]"
                                                                value="<?php echo e($subValue); ?>"
                                                                class="w-full rounded-lg border border-[#d7d9e4] px-3 py-2 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20" />
                                                        <?php endif; ?>
                                                    </div>
                                                <?php elseif(is_array($subValue)): ?>
                                                    
                                                    <div class="sm:col-span-2">
                                                        <label
                                                            class="mb-2 block text-xs font-semibold text-[#b28b2e]"><?php echo e(ucwords(str_replace('_', ' ', $subKey))); ?></label>
                                                        <div class="space-y-3">
                                                            <?php $__currentLoopData = $subValue; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $j => $nestedItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                <?php if(is_array($nestedItem)): ?>
                                                                    <div
                                                                        class="rounded-lg border border-dashed border-[#d7d9e4] bg-[#f9fafb] p-4">
                                                                        <div class="grid gap-3 sm:grid-cols-2">
                                                                            <?php $__currentLoopData = $nestedItem; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $nk => $nv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                                                <div>
                                                                                    <label
                                                                                        class="mb-1 block text-xs text-[#6b6b66]"><?php echo e(ucwords(str_replace('_', ' ', $nk))); ?></label>
                                                                                    <input type="text"
                                                                                        name="content[<?php echo e($key); ?>][<?php echo e($i); ?>][<?php echo e($subKey); ?>][<?php echo e($j); ?>][<?php echo e($nk); ?>]"
                                                                                        value="<?php echo e($nv); ?>"
                                                                                        class="w-full rounded-lg border border-[#d7d9e4] px-3 py-2 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20" />
                                                                                </div>
                                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                                        </div>
                                                                    </div>
                                                                <?php endif; ?>
                                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                        </div>
                                                    </div>
                                                <?php endif; ?>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </div>
                                    </div>
                                <?php elseif(is_string($item)): ?>
                                    
                                    <div>
                                        <input type="text" name="content[<?php echo e($key); ?>][<?php echo e($i); ?>]"
                                            value="<?php echo e($item); ?>"
                                            class="w-full rounded-lg border border-[#d7d9e4] px-3 py-2 text-sm text-[#2e2e2e] outline-none transition focus:border-[#287854] focus:ring-2 focus:ring-[#287854]/20" />
                                    </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>

        <div class="mt-8 flex items-center gap-4">
            <button type="submit"
                class="inline-flex items-center gap-2 rounded-xl bg-[#287854] px-6 py-3 text-sm font-semibold text-white shadow-sm transition hover:bg-[#1f5f46]">
                <svg class="h-4 w-4" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2">
                    <path d="M19 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h11l5 5v11a2 2 0 0 1-2 2z" />
                    <polyline points="17 21 17 13 7 13 7 21" />
                    <polyline points="7 3 7 8 15 8" />
                </svg>
                Save Changes
            </button>
            <a href="<?php echo e(route('admin.dashboard')); ?>"
                class="text-sm font-medium text-[#6b6b66] transition hover:text-[#2e2e2e]">Cancel</a>
        </div>
    </form>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /Users/widawatimanuaba/Documents/Dio's Works/stafflink_web/resources/views/admin/edit.blade.php ENDPATH**/ ?>