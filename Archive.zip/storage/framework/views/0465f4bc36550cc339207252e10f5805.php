<?php $attributes ??= new \Illuminate\View\ComponentAttributeBag;

$__newAttributes = [];
$__propNames = \Illuminate\View\ComponentAttributeBag::extractPropNames((['content' => []]));

foreach ($attributes->all() as $__key => $__value) {
    if (in_array($__key, $__propNames)) {
        $$__key = $$__key ?? $__value;
    } else {
        $__newAttributes[$__key] = $__value;
    }
}

$attributes = new \Illuminate\View\ComponentAttributeBag($__newAttributes);

unset($__propNames);
unset($__newAttributes);

foreach (array_filter((['content' => []]), 'is_string', ARRAY_FILTER_USE_KEY) as $__key => $__value) {
    $$__key = $$__key ?? $__value;
}

$__defined_vars = get_defined_vars();

foreach ($attributes->all() as $__key => $__value) {
    if (array_key_exists($__key, $__defined_vars)) unset($$__key);
}

unset($__defined_vars, $__key, $__value); ?>

<section class="px-6 pb-24">
    <div class="mx-auto max-w-6xl">
        <p class="text-center text-xs uppercase tracking-[0.3em] text-[#b28b2e]" data-aos="fade-up">
            <?php echo e($content['badge'] ?? 'Talent solutions'); ?></p>
        <h2 class="mt-3 text-center text-3xl font-semibold" data-aos="fade-up" data-aos-delay="100">
            <?php echo e($content['title'] ?? ''); ?></h2>
        <p class="mx-auto mt-3 max-w-2xl text-center text-sm text-[#6b6b66]" data-aos="fade-up" data-aos-delay="150">
            <?php echo e($content['subtitle'] ?? ''); ?>

        </p>
        <div class="mt-10 grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            <?php $__currentLoopData = $content['cards'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $i => $card): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button
                    class="group overflow-hidden rounded-2xl bg-white text-left shadow-sm transition duration-300 ease-out hover:-translate-y-1 hover:shadow-md"
                    data-modal-target="talent" data-talent-title="<?php echo e($card['title'] ?? ''); ?>"
                    data-talent-description="<?php echo e($card['description'] ?? ''); ?>"
                    data-talent-jobs='<?php echo json_encode($card['jobs'] ?? [], 15, 512) ?>' data-aos="fade-up"
                    data-aos-delay="<?php echo e(100 + $i * 50); ?>">
                    <img src="<?php echo e($card['image'] ?? ''); ?>" alt="<?php echo e($card['title'] ?? ''); ?>"
                        class="h-32 w-full object-cover transition duration-300 ease-out group-hover:scale-105"
                        draggable="false" />
                    <div class="px-5 py-5">
                        <h3 class="text-base font-semibold"><?php echo e($card['title'] ?? ''); ?></h3>
                        <p class="mt-2 text-sm text-[#6b6b66]"><?php echo e($card['description'] ?? ''); ?></p>
                    </div>
                </button>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="mt-10 flex justify-center" data-aos="fade-up" data-aos-delay="500">
            <button
                class="rounded-full bg-[#b28b2e] px-6 py-2 text-sm font-semibold text-white shadow-sm transition hover:bg-[#9b7829]"
                data-modal-target="overview">
                More Details
            </button>
        </div>
    </div>

    <div class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 px-6" data-modal="overview">
        <div class="w-full max-w-3xl rounded-3xl bg-white p-8 shadow-[0_30px_70px_rgba(31,95,70,0.25)]" data-modal-panel>
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <p class="text-xs uppercase tracking-[0.3em] text-[#b28b2e]">Open roles</p>
                    <h3 class="mt-2 text-2xl font-semibold">Current staffing opportunities</h3>
                </div>
                <button class="rounded-full border border-[#d7d9e4] px-4 py-2 text-xs font-semibold text-[#4a4a45]"
                    data-modal-close>
                    Close
                </button>
            </div>
            <div class="mt-6 grid gap-5 sm:grid-cols-2">
                <?php $__currentLoopData = $content['modal_roles'] ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <div class="rounded-2xl border border-[#ececf4] p-4">
                        <h4 class="text-base font-semibold"><?php echo e($role['title'] ?? ''); ?></h4>
                        <p class="mt-2 text-sm text-[#6b6b66]"><?php echo e($role['description'] ?? ''); ?></p>
                    </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
        </div>
    </div>

    <div class="fixed inset-0 z-50 hidden items-center justify-center bg-black/40 px-6" data-modal="talent">
        <div class="w-full max-w-3xl rounded-3xl bg-white p-8 shadow-[0_30px_70px_rgba(31,95,70,0.25)]" data-modal-panel>
            <div class="flex flex-wrap items-center justify-between gap-4">
                <div>
                    <p class="text-xs uppercase tracking-[0.3em] text-[#b28b2e]">Talent focus</p>
                    <h3 class="mt-2 text-2xl font-semibold" data-talent-title></h3>
                    <p class="mt-2 text-sm text-[#6b6b66]" data-talent-description></p>
                </div>
                <button class="rounded-full border border-[#d7d9e4] px-4 py-2 text-xs font-semibold text-[#4a4a45]"
                    data-modal-close>
                    Close
                </button>
            </div>
            <div class="mt-6 grid gap-5 sm:grid-cols-2" data-talent-jobs></div>
        </div>
    </div>
</section>
<?php /**PATH /Users/widawatimanuaba/Documents/Dio's Works/stafflink_web/resources/views/components/staffing.blade.php ENDPATH**/ ?>