<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?php echo e(config('app.name', 'StaffLink')); ?> - Jobs</title>

    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link
        href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&family=Google+Sans:wght@400;500;600;700&display=swap"
        rel="stylesheet">
    <link rel="stylesheet" href="https://unpkg.com/aos@2.3.4/dist/aos.css">
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>

<body class="text-[#2e2e2e]" id="page-top">
    <div class="min-h-screen bg-[radial-gradient(circle_at_top,_#ffffff_0%,_#f4f5f3_52%,_#e6f1ec_100%)]">
        <?php if (isset($component)) { $__componentOriginalfdc8967a87956c0a7185abbef03fae20 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginalfdc8967a87956c0a7185abbef03fae20 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-header','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-header'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $attributes = $__attributesOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__attributesOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>
<?php if (isset($__componentOriginalfdc8967a87956c0a7185abbef03fae20)): ?>
<?php $component = $__componentOriginalfdc8967a87956c0a7185abbef03fae20; ?>
<?php unset($__componentOriginalfdc8967a87956c0a7185abbef03fae20); ?>
<?php endif; ?>
        <main class="px-10 pb-28 pt-14 lg:px-12">
            <section class="mx-auto max-w-7xl space-y-14">
                <div class="rounded-[30px] bg-[#1f5f46] p-12 text-white shadow-[0_20px_50px_rgba(31,95,70,0.2)] lg:p-10 mb-5"
                    data-aos="fade-up">
                    <p class="text-xs uppercase tracking-[0.3em] text-[#e9d29d]">Careers</p>
                    <h1 class="mt-4 text-4xl font-semibold">Available Jobs</h1>
                    <p class="mt-4 max-w-2xl text-sm text-white/85">
                        Explore our current openings posted by StaffLink admin team. Find the right role and apply now.
                    </p>
                </div>

                <section class="rounded-2xl bg-white p-5 mb-5 shadow-[0_16px_40px_rgba(31,95,70,0.1)]"
                    data-aos="fade-up">
                    <div class="grid gap-4 md:grid-cols-2 lg:grid-cols-[1fr_190px_190px_220px_auto] md:items-end">
                        <div>
                            <label for="job-search" class="text-sm font-semibold text-[#2e2e2e]">Filter by name</label>
                            <input id="job-search" type="text" placeholder="Search job title..."
                                value="<?php echo e(request('search')); ?>"
                                class="mt-2 w-full rounded-xl border border-[#d1d5db] px-4 py-3 text-sm focus:border-[#287854] focus:outline-none">
                        </div>
                        <div>
                            <label for="job-type-filter" class="text-sm font-semibold text-[#2e2e2e]">Category</label>
                            <select id="job-type-filter"
                                class="mt-2 w-full rounded-xl border border-[#d1d5db] px-4 py-3 text-sm focus:border-[#287854] focus:outline-none">
                                <option value="" <?php echo e(request('type') === null || request('type') === '' ? 'selected' : ''); ?>>All categories</option>
                                <option value="full-time" <?php echo e(request('type') === 'full-time' ? 'selected' : ''); ?>>Full Time</option>
                                <option value="part-time" <?php echo e(request('type') === 'part-time' ? 'selected' : ''); ?>>Part Time</option>
                                <option value="contract" <?php echo e(request('type') === 'contract' ? 'selected' : ''); ?>>Contract</option>
                            </select>
                        </div>
                        <div>
                            <label for="job-location-filter" class="text-sm font-semibold text-[#2e2e2e]">Location</label>
                            <select id="job-location-filter"
                                class="mt-2 w-full rounded-xl border border-[#d1d5db] px-4 py-3 text-sm focus:border-[#287854] focus:outline-none">
                                <option value="" <?php echo e(request('location') === null || request('location') === '' ? 'selected' : ''); ?>>All locations</option>
                                <?php $__currentLoopData = $locationOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>" <?php echo e(request('location') === $option ? 'selected' : ''); ?>>
                                        <?php echo e($option); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <div>
                            <label for="job-salary-filter" class="text-sm font-semibold text-[#2e2e2e]">Salary range</label>
                            <select id="job-salary-filter"
                                class="mt-2 w-full rounded-xl border border-[#d1d5db] px-4 py-3 text-sm focus:border-[#287854] focus:outline-none">
                                <option value="" <?php echo e(request('salary_range') === null || request('salary_range') === '' ? 'selected' : ''); ?>>All salary ranges</option>
                                <?php $__currentLoopData = $salaryRangeOptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $option): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($option); ?>" <?php echo e(request('salary_range') === $option ? 'selected' : ''); ?>>
                                        <?php echo e($option); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                        <button id="job-filter-reset" type="button"
                            class="rounded-xl border border-[#b5d6c5] bg-[#ecf7f1] px-4 py-3 text-sm font-semibold text-[#1f5f46] hover:bg-[#e3f1ea]">
                            Reset
                        </button>
                    </div>
                </section>

                <div id="jobs-container" class="grid gap-5 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4"
                    data-next-page-url="<?php echo e($jobs->nextPageUrl()); ?>" data-aos="fade-up">
                    <?php echo $__env->make('partials.job-cards', ['jobs' => $jobs], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                </div>

                <div id="jobs-loading" class="hidden py-4 text-center text-sm font-semibold text-[#287854]">Loading more
                    jobs...</div>
                <div id="jobs-end" class="hidden py-4 text-center text-sm text-[#6b6b66]">No more jobs to load.</div>
                <div id="jobs-sentinel" class="h-1"></div>
            </section>
        </main>
        <?php if (isset($component)) { $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.site-footer','data' => []] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('site-footer'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $attributes = $__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__attributesOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1)): ?>
<?php $component = $__componentOriginal222c87a019257fb1d70ae0ff46ab02e1; ?>
<?php unset($__componentOriginal222c87a019257fb1d70ae0ff46ab02e1); ?>
<?php endif; ?>
    </div>
    <script src="https://unpkg.com/aos@2.3.4/dist/aos.js"></script>
    <script>
        (() => {
            const container = document.getElementById('jobs-container');
            const sentinel = document.getElementById('jobs-sentinel');
            const loading = document.getElementById('jobs-loading');
            const endText = document.getElementById('jobs-end');
            const searchInput = document.getElementById('job-search');
            const typeSelect = document.getElementById('job-type-filter');
            const locationSelect = document.getElementById('job-location-filter');
            const salarySelect = document.getElementById('job-salary-filter');
            const resetBtn = document.getElementById('job-filter-reset');

            if (!container || !sentinel) return;

            let nextPageUrl = container.dataset.nextPageUrl || '';
            let isLoading = false;
            let debounceTimer = null;
            let activeController = null;

            const setLoading = (state) => {
                isLoading = state;
                loading.classList.toggle('hidden', !state);
            };

            const buildUrl = (page = 1) => {
                const url = new URL("<?php echo e(route('jobs.index')); ?>", window.location.origin);
                if (searchInput.value.trim() !== '') url.searchParams.set('search', searchInput.value.trim());
                if (typeSelect.value) url.searchParams.set('type', typeSelect.value);
                if (locationSelect.value) url.searchParams.set('location', locationSelect.value);
                if (salarySelect.value) url.searchParams.set('salary_range', salarySelect.value);
                url.searchParams.set('page', String(page));
                return url.toString();
            };

            const fetchJobs = async ({
                reset = false
            } = {}) => {
                if (isLoading) return;
                if (!reset && !nextPageUrl) return;

                setLoading(true);
                endText.classList.add('hidden');

                if (activeController) activeController.abort();
                activeController = new AbortController();

                const targetUrl = reset ? buildUrl(1) : nextPageUrl;

                try {
                    const response = await fetch(targetUrl, {
                        headers: {
                            'Accept': 'application/json',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        signal: activeController.signal,
                    });

                    if (!response.ok) throw new Error('Failed to load jobs');

                    const data = await response.json();
                    nextPageUrl = data.next_page_url || '';

                    if (reset) {
                        container.innerHTML = data.html || '';
                    } else {
                        container.insertAdjacentHTML('beforeend', data.html || '');
                    }

                    if (!nextPageUrl) {
                        endText.classList.remove('hidden');
                    }
                } catch (error) {
                    if (error.name !== 'AbortError') {
                        console.error(error);
                    }
                } finally {
                    setLoading(false);
                }
            };

            const observer = new IntersectionObserver((entries) => {
                entries.forEach((entry) => {
                    if (entry.isIntersecting && nextPageUrl && !isLoading) {
                        fetchJobs();
                    }
                });
            }, {
                rootMargin: '160px 0px'
            });

            observer.observe(sentinel);

            const triggerFilter = () => {
                if (debounceTimer) clearTimeout(debounceTimer);
                debounceTimer = setTimeout(() => {
                    nextPageUrl = '';
                    fetchJobs({
                        reset: true
                    });
                }, 280);
            };

            searchInput.addEventListener('input', triggerFilter);
            typeSelect.addEventListener('change', triggerFilter);
            locationSelect.addEventListener('change', triggerFilter);
            salarySelect.addEventListener('change', triggerFilter);

            resetBtn.addEventListener('click', () => {
                searchInput.value = '';
                typeSelect.value = '';
                locationSelect.value = '';
                salarySelect.value = '';
                triggerFilter();
            });
        })();
    </script>
</body>

</html>
<?php /**PATH /Users/widawatimanuaba/Documents/Dio's Works/stafflink_web/resources/views/jobs.blade.php ENDPATH**/ ?>