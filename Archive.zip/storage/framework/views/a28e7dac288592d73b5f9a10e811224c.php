<?php $__empty_1 = true; $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
    <article class="mb-2 flex h-full flex-col rounded-xl border border-[#d9e3dc] bg-white p-5 shadow-[0_10px_24px_rgba(31,95,70,0.08)]">
        <div class="flex items-start justify-between gap-3">
            <h2 class="text-lg font-semibold text-[#1b1b18]"><?php echo e($job->title); ?></h2>
            <span
                class="shrink-0 whitespace-nowrap rounded-full border border-[#b5d6c5] bg-[#ecf7f1] px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-[#1f5f46]">
                <?php echo e(ucwords(str_replace('-', ' ', $job->type))); ?>

            </span>
        </div>

        <div class="mt-3 space-y-1 text-xs text-[#6b6b66]">
            <p><span class="font-semibold text-[#2e2e2e]">Location:</span>
                <?php echo e($job->location ?: 'Not specified'); ?></p>
            <?php if($job->salary_range): ?>
                <p><span class="font-semibold text-[#2e2e2e]">Salary:</span>
                    <?php echo e($job->salary_range); ?></p>
            <?php endif; ?>
            <p><span class="font-semibold text-[#2e2e2e]">Posted:</span>
                <?php echo e(($job->published_at ?? $job->created_at)->format('d M Y')); ?></p>
        </div>

        <p class="mt-3 text-xs leading-relaxed text-[#6b6b66]">
            <?php echo e(\Illuminate\Support\Str::limit(strip_tags($job->description), 120)); ?>

        </p>

        <div class="mt-auto pt-4">
            <a href="<?php echo e(route('applications.create')); ?>"
                class="inline-flex w-full items-center justify-center rounded-full border border-[#287854] bg-white px-4 py-2 text-xs font-semibold text-[#287854] transition hover:bg-[#287854] hover:text-white">
                Apply now
            </a>
        </div>
    </article>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
    <div class="col-span-full rounded-2xl bg-white p-10 text-center shadow-[0_20px_50px_rgba(31,95,70,0.12)]">
        <h2 class="text-2xl font-semibold text-[#1b1b18]">No jobs match your filter</h2>
        <p class="mt-3 text-sm text-[#6b6b66]">Try changing the job type or search keyword.</p>
    </div>
<?php endif; ?>
<?php /**PATH /Users/widawatimanuaba/Documents/Dio's Works/stafflink_web/resources/views/partials/job-cards.blade.php ENDPATH**/ ?>