@forelse ($jobs as $job)
    @php
        $waNumber = preg_replace('/\D+/', '', (string) config('services.whatsapp.inquiry_number', ''));
        $inquiryTemplate = (string) ($job->whatsapp_inquiry_template ?: config('services.whatsapp.inquiry_template', 'Hi Staff Link, I am interested in the {position} role ({work_mode}) in {location}.'));
        $inquiryMessage = strtr($inquiryTemplate, [
            '{position}' => (string) $job->title,
            '{location}' => (string) ($job->location_display ?: 'Not specified'),
            '{work_mode}' => strtoupper((string) ($job->work_mode ?: 'hybrid')),
        ]);
        $inquiryUrl = $waNumber !== '' ? 'https://wa.me/' . $waNumber . '?text=' . urlencode($inquiryMessage) : null;
    @endphp
    <article class="mb-2 flex h-full flex-col rounded-xl border border-[#d9e3dc] bg-white p-5 shadow-[0_10px_24px_rgba(31,95,70,0.08)]">
        <div class="flex items-start justify-between gap-3">
            <h2 class="text-lg font-semibold text-[#1b1b18]">{{ $job->title }}</h2>
            <div class="flex flex-col items-end gap-1">
                <span
                    class="shrink-0 whitespace-nowrap rounded-full border border-[#b5d6c5] bg-[#ecf7f1] px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-[#1f5f46]">
                    {{ ucwords(str_replace('-', ' ', $job->type)) }}
                </span>
                <span class="shrink-0 whitespace-nowrap rounded-full border border-[#d7c27b] bg-[#fbf4dc] px-2.5 py-1 text-[11px] font-semibold uppercase tracking-wide text-[#8b6d1a]">
                    {{ strtoupper((string) ($job->work_mode ?: 'hybrid')) }}
                </span>
            </div>
        </div>

        <div class="mt-3 space-y-1 text-xs text-[#6b6b66]">
            <p><span class="font-semibold text-[#2e2e2e]">Location:</span>
                {{ $job->location_display ?: 'Not specified' }}</p>
            @if ($job->salary_range)
                <p><span class="font-semibold text-[#2e2e2e]">Salary:</span>
                    {{ $job->salary_range }}</p>
            @endif
            <p><span class="font-semibold text-[#2e2e2e]">Posted:</span>
                {{ ($job->published_at ?? $job->created_at)->format('d M Y') }}</p>
        </div>

        <div class="mt-auto pt-4">
            @if ($inquiryUrl)
                <div class="flex items-stretch gap-2">
                    <a href="{{ route('applications.create', ['job_id' => $job->id]) }}"
                        class="inline-flex w-4/5 items-center justify-center rounded-full border border-[#287854] bg-white px-4 py-2 text-xs font-semibold text-[#287854] transition hover:bg-[#287854] hover:text-white">
                        Apply now
                    </a>
                    <a href="{{ $inquiryUrl }}" target="_blank" rel="noopener" aria-label="Ask via WhatsApp"
                        class="inline-flex w-1/5 items-center justify-center rounded-full bg-[#25d366] px-2 py-2 text-white transition hover:bg-[#1eb95a]">
                        <img src="{{ asset('images/64px-WhatsApp.svg.png') }}" alt="WhatsApp" class="h-5 w-5" draggable="false" loading="lazy" />
                    </a>
                </div>
            @else
                <a href="{{ route('applications.create', ['job_id' => $job->id]) }}"
                    class="inline-flex w-full items-center justify-center rounded-full border border-[#287854] bg-white px-4 py-2 text-xs font-semibold text-[#287854] transition hover:bg-[#287854] hover:text-white">
                    Apply now
                </a>
            @endif
        </div>
    </article>
@empty
    <div class="col-span-full rounded-2xl bg-white p-10 text-center shadow-[0_20px_50px_rgba(31,95,70,0.12)]">
        <h2 class="text-2xl font-semibold text-[#1b1b18]">Currently no jobs available</h2>
        <p class="mt-3 text-sm text-[#6b6b66]">Please check back later for new openings.</p>
    </div>
@endforelse
