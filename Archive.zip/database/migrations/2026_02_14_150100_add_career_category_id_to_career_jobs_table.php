<?php

use Illuminate\Database\Migrations\Migration;

return new class extends Migration
{
    public function up(): void
    {
        // No-op migration retained to avoid changing previously generated filenames.
    }

    public function down(): void
    {
        // No-op
    }
};
