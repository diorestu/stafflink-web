<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @include('partials.gtag-head')
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @include('partials.seo-meta', [
        'seoTitle' => \App\Models\SiteSetting::siteName().' | Wedding Organizer Services',
        'seoDescription' => 'Plan your special day with Staff Link wedding organizer services, from concept and vendor coordination to on-day execution in Bali.',
        'seoKeywords' => 'wedding organizer bali, wedding planning service, event coordination bali',
    ])
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="text-[#2e2e2e]">
    @include('partials.gtm-noscript')
    <div class="min-h-screen bg-[radial-gradient(circle_at_top,_#fff7fb_0%,_#fff1f8_42%,_#ffffff_100%)]">
        <x-site-header />

        <main class="px-6 pb-20 pt-12 lg:px-10">
            <section class="mx-auto max-w-5xl space-y-8">
                <header class="relative overflow-hidden rounded-[28px] p-8 text-white shadow-[0_20px_60px_rgba(123,18,72,0.42)] lg:p-12">
                    <img src="https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1600&q=80"
                        alt="Wedding ceremony setup with flowers and decor"
                        class="absolute inset-0 h-full w-full object-cover"
                        loading="lazy">
                    <div class="absolute inset-0 bg-[linear-gradient(140deg,rgba(143,20,84,0.88)_0%,rgba(123,18,72,0.82)_55%,rgba(102,15,59,0.8)_100%)]"></div>
                    <div class="relative z-10">
                        <p class="inline-flex items-center rounded-full border border-white/40 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white">Services</p>
                        <h1 class="mt-4 text-3xl font-semibold leading-tight lg:text-5xl">Wedding Organizers &amp; Wedding Planners in Bali</h1>
                        <p class="mt-5 max-w-3xl text-sm italic leading-relaxed text-white/90">
                            Premium weddings demand structure, financial discipline, and flawless execution. They should also feel effortless, meaningful, and unforgettable.
                            At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali transform your vision into a beautifully executed celebration where creativity meets disciplined planning, and every detail reflects your story with precision and care.
                        </p>
                        <div class="mt-7 flex flex-wrap items-center justify-start gap-3">
                            <a href="{{ route('appointments.create') }}" class="inline-flex rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-[#d53e89] transition hover:bg-[#fff0f8]">Book a Wedding Consultation with Us</a>
                            <a href="{{ route('contact') }}" class="inline-flex rounded-full border border-white/50 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-white/15">Contact Our Wedding Team</a>
                        </div>
                    </div>
                </header>

                <section class="rounded-2xl bg-white p-7 shadow-[0_14px_40px_rgba(213,62,137,0.13)] lg:p-9">
                    <h2 class="text-2xl font-semibold text-[#1b1b18]">Wedding Organizers &amp; Wedding Planners in Bali - Turning Vision into Reality</h2>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali begin with your dream concept and translate it into a clear execution roadmap, balancing creativity, budget control, and seamless coordination.
                    </p>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        We bring meaningful celebrations to life with structure behind every beautiful detail, ensuring your ideas evolve from inspiration into an unforgettable reality.
                    </p>
                    <div class="mt-4 grid gap-4 md:grid-cols-2">
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - Concept and Timeline Planning</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali define your event flow, guest journey, and milestone timeline to ensure disciplined planning from preparation through post-event wrap-up.</p>
                            <p class="mt-2 text-sm text-[#5a5a55]">We shape your vision into a seamless sequence of moments that unfold naturally and beautifully.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - Vendor and Contract Coordination</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali manage vendor negotiations, contracts, and payment schedules to protect your budget and maintain operational clarity.</p>
                            <p class="mt-2 text-sm text-[#5a5a55]">Let us take care of the details and ensure everything is handled properly so you can relax, enjoy, and celebrate every moment stress-free, full of smiles and love.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - Guest and Logistics Management</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali curate guest flow, comfort, and hospitality so every attendee feels part of an unforgettable celebration.</p>
                            <p class="mt-2 text-sm text-[#5a5a55]">We create an atmosphere where your family and friends feel welcomed, supported, and fully present on your special day.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - On Day Execution Control</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali manage every moving part behind the scenes, allowing you to stay present, confident, and fully immersed in your special day.</p>
                            <p class="mt-2 text-sm text-[#5a5a55]">While we oversee the coordination, you simply embrace the joy of the moment.</p>
                        </article>
                    </div>
                </section>

                <section class="rounded-2xl bg-white p-7 shadow-[0_14px_40px_rgba(213,62,137,0.13)] lg:p-9">
                    <h2 class="text-2xl font-semibold text-[#1b1b18]">Wedding Organizers &amp; Wedding Planners in Bali - Destination Wedding Coordination</h2>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali manage cross-border planning, structured communication, and remote coordination for international couples choosing Bali.
                    </p>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        We guide you with clarity and reassurance throughout the process, ensuring distance never limits the wedding experience you envision.
                    </p>
                </section>

                <section class="rounded-2xl border border-[#f3c9df] bg-[#fff6fb] p-7 shadow-[0_14px_40px_rgba(213,62,137,0.12)] lg:p-9">
                    <p class="text-xs font-semibold uppercase tracking-[0.2em] text-[#a33872]">Wedding Organizers &amp; Wedding Planners in Bali</p>
                    <h2 class="mt-3 text-2xl font-semibold leading-tight text-[#7b1248] lg:text-3xl">Wedding Organizers &amp; Wedding Planners in Bali - Child-Friendly Guest Experience Coordination</h2>
                    <p class="mt-3 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali design structured child-friendly experiences as an optional add-on to support families attending your celebration. We prepare a dedicated guest list for attendees requiring nanny assistance, coordinate supervised children’s activity areas, and arrange refined entertainment elements such as elegant white bouncy castles and professionally managed face-painting sessions, ensuring young guests are engaged while adults celebrate with complete peace of mind.
                    </p>
                    <h3 class="mt-5 text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - Professional Nanny Support</h3>
                    <p class="mt-2 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali match experienced and vetted nanny professionals based on guest count, age groups, and venue requirements to provide reliable supervision and structured childcare coverage throughout the event.
                    </p>
                    <h3 class="mt-5 text-lg font-semibold text-[#d53e89]">Wedding Organizers &amp; Wedding Planners in Bali - Children’s Activity Coordination</h3>
                    <p class="mt-2 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali coordinate supervised entertainment areas, including elegant white bouncy castles and professionally managed face-painting sessions, to ensure young guests are safely engaged in a dedicated environment during the celebration.
                    </p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <a href="{{ route('forms.nannies-inquiry') }}" class="inline-flex rounded-full bg-[#d53e89] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#b82f73]">
                            Open Nanny Inquiry Form
                        </a>
                        <a href="{{ route('contact') }}" class="inline-flex rounded-full border border-[#d88ab3] px-6 py-3 text-sm font-semibold text-[#7b1248] transition hover:bg-[#ffe8f4]">
                            Ask Our Team First
                        </a>
                    </div>
                </section>

                <section class="rounded-[26px] bg-[linear-gradient(140deg,_#8f1454_0%,_#7b1248_55%,_#660f3b_100%)] p-8 text-white shadow-[0_20px_60px_rgba(123,18,72,0.35)] lg:p-10">
                    <p class="text-xs font-semibold uppercase tracking-[0.2em] text-white/80">Wedding Organizers &amp; Wedding Planners in Bali</p>
                    <h2 class="mt-3 text-2xl font-semibold leading-tight lg:text-3xl">Wedding Organizers &amp; Wedding Planners in Bali - Service Consultation</h2>
                    <p class="mt-3 max-w-3xl text-sm leading-relaxed text-white/90">
                        At Staff Link, our Wedding Organizers &amp; Wedding Planners in Bali begin with a structured consultation to assess event scale, venue selection, budget framework, and execution requirements.
                    </p>
                    <p class="mt-3 max-w-3xl text-sm leading-relaxed text-white/90">
                        We recommend the appropriate coordination model to ensure premium standards, disciplined delivery, and a wedding experience that feels as exceptional as it looks.
                    </p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <a href="{{ route('contact') }}" class="inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-[#7b1248] transition hover:bg-[#ffe7f3]">
                            Contact Us
                        </a>
                        <a href="{{ route('appointments.create') }}" class="inline-flex rounded-full border border-white/45 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/15">
                            Book a Consultation with Us
                        </a>
                    </div>
                </section>
            </section>
        </main>

        <x-site-footer />
    </div>
</body>
</html>
