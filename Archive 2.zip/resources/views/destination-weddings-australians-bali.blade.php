<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    @include('partials.gtag-head')
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    @include('partials.seo-meta', [
        'seoTitle' => \App\Models\SiteSetting::siteName().' | Destination Weddings for Australians in Bali',
        'seoDescription' => 'Plan a seamless Bali destination wedding for Australian couples with structured coordination, vendor control, and premium guest experience support.',
        'seoKeywords' => 'destination wedding bali for australians, bali wedding planner australian couples, wedding organizer bali australia',
    ])
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="text-[#2e2e2e]">
    @include('partials.gtm-noscript')
    <div class="min-h-screen bg-[radial-gradient(circle_at_top,_#fff7fb_0%,_#fff1f8_42%,_#ffffff_100%)]">
        <x-site-header />

        <main class="px-6 pb-20 pt-12 lg:px-10">
            <section class="mx-auto max-w-5xl space-y-8">
                <header class="relative overflow-hidden rounded-[28px] p-8 text-white shadow-[0_20px_60px_rgba(123,18,72,0.42)] lg:p-12">
                    <img src="https://images.unsplash.com/photo-1520854221256-17451cc331bf?auto=format&fit=crop&w=1600&q=80"
                        alt="Destination wedding in Bali"
                        class="absolute inset-0 h-full w-full object-cover"
                        loading="lazy">
                    <div class="absolute inset-0 bg-[linear-gradient(140deg,rgba(143,20,84,0.88)_0%,rgba(123,18,72,0.82)_55%,rgba(102,15,59,0.8)_100%)]"></div>
                    <div class="relative z-10">
                        <p class="inline-flex items-center rounded-full border border-white/40 bg-white/10 px-3 py-1 text-xs font-semibold uppercase tracking-[0.18em] text-white">Destination Weddings</p>
                        <h1 class="mt-4 text-3xl font-semibold leading-tight lg:text-5xl">Destination Weddings for Australians Getting Married in Bali</h1>
                        <p class="mt-5 max-w-3xl text-sm italic leading-relaxed text-white/90">
                            Bali weddings should feel magical, not overwhelming. At Staff Link, we support Australian couples with structured destination wedding planning that combines creative vision, budget clarity, and flawless on-day execution.
                        </p>
                        <div class="mt-7 flex flex-wrap items-center justify-start gap-3">
                            <a href="{{ route('appointments.create') }}" class="inline-flex rounded-full bg-white px-5 py-2.5 text-sm font-semibold text-[#d53e89] transition hover:bg-[#fff0f8]">Book a Wedding Consultation with Us</a>
                            <a href="{{ route('contact') }}" class="inline-flex rounded-full border border-white/50 px-5 py-2.5 text-sm font-semibold text-white transition hover:bg-white/15">Contact Our Wedding Team</a>
                        </div>
                    </div>
                </header>

                <section class="rounded-2xl bg-white p-7 shadow-[0_14px_40px_rgba(213,62,137,0.13)] lg:p-9">
                    <h2 class="text-2xl font-semibold text-[#1b1b18]">Wedding Planners in Bali for Australian Couples - Turning Vision into Reality</h2>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        Our Bali wedding planners work closely with Australian couples to transform ideas into a practical, high-performing execution plan. From concept to vendor strategy, we align every phase around quality, cost control, and timeline precision.
                    </p>
                    <div class="mt-4 grid gap-4 md:grid-cols-2">
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Concept and Timeline Planning</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">We build a complete wedding roadmap covering planning milestones, vendor deadlines, and event flow from pre-arrival to post-event close.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Vendor and Contract Coordination</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">We coordinate sourcing, negotiations, and contracts to protect your budget and ensure each supplier delivers to agreed standards.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">Guest and Logistics Management</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">From airport arrivals to accommodation flow and ceremony transitions, we keep every guest touchpoint organized and stress-free.</p>
                        </article>
                        <article class="rounded-xl border border-[#f4cde2] bg-[#fff7fb] p-5">
                            <h3 class="text-lg font-semibold text-[#d53e89]">On-Day Execution Control</h3>
                            <p class="mt-2 text-sm text-[#5a5a55]">Our coordinators manage all moving parts behind the scenes, so you can stay fully present and enjoy your wedding day with confidence.</p>
                        </article>
                    </div>
                </section>

                <section class="rounded-2xl bg-white p-7 shadow-[0_14px_40px_rgba(213,62,137,0.13)] lg:p-9">
                    <h2 class="text-2xl font-semibold text-[#1b1b18]">Australia to Bali Wedding Coordination - Clear Communication Across Borders</h2>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        Planning from Australia should never compromise quality in Bali. We provide structured remote coordination, clear communication cadence, and transparent planning updates so distance never becomes a risk factor.
                    </p>
                    <p class="mt-3 text-sm leading-relaxed text-[#5a5a55]">
                        You receive one coordinated planning experience with local Bali execution standards and international-level professionalism.
                    </p>
                </section>

                <section class="rounded-2xl border border-[#f3c9df] bg-[#fff6fb] p-7 shadow-[0_14px_40px_rgba(213,62,137,0.12)] lg:p-9">
                    <p class="text-xs font-semibold uppercase tracking-[0.2em] text-[#a33872]">Family-Friendly Destination Wedding Support</p>
                    <h2 class="mt-3 text-2xl font-semibold leading-tight text-[#7b1248] lg:text-3xl">Child-Friendly Guest Experience Coordination</h2>
                    <p class="mt-3 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        For couples hosting family-inclusive celebrations, we coordinate optional childcare support including nanny staffing plans, supervised activity zones, and curated experiences for young guests.
                    </p>
                    <h3 class="mt-5 text-lg font-semibold text-[#d53e89]">Professional Nanny Support</h3>
                    <p class="mt-2 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        We match vetted nanny professionals by guest count, children age groups, and venue requirements to ensure reliable event-day supervision.
                    </p>
                    <h3 class="mt-5 text-lg font-semibold text-[#d53e89]">Children's Activity Coordination</h3>
                    <p class="mt-2 max-w-3xl text-sm leading-relaxed text-[#5a5a55]">
                        We can coordinate elegant white bouncy castles and professionally managed face-painting stations to keep children safely engaged while adults celebrate.
                    </p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <a href="{{ route('forms.nannies-inquiry') }}" class="inline-flex rounded-full bg-[#d53e89] px-6 py-3 text-sm font-semibold text-white transition hover:bg-[#b82f73]">
                            Open Nanny Inquiry Form
                        </a>
                        <a href="{{ route('contact') }}" class="inline-flex rounded-full border border-[#d88ab3] px-6 py-3 text-sm font-semibold text-[#7b1248] transition hover:bg-[#ffe8f4]">
                            Ask Our Team First
                        </a>
                    </div>
                </section>

                <section class="rounded-[26px] bg-[linear-gradient(140deg,_#8f1454_0%,_#7b1248_55%,_#660f3b_100%)] p-8 text-white shadow-[0_20px_60px_rgba(123,18,72,0.35)] lg:p-10">
                    <p class="text-xs font-semibold uppercase tracking-[0.2em] text-white/80">Destination Wedding Consultation</p>
                    <h2 class="mt-3 text-2xl font-semibold leading-tight lg:text-3xl">Plan Your Australian-Bali Wedding with Confidence</h2>
                    <p class="mt-3 max-w-3xl text-sm leading-relaxed text-white/90">
                        Start with a structured consultation to align budget, venue, guest profile, and execution requirements. We will recommend the right coordination model for a premium, seamless Bali destination wedding.
                    </p>
                    <div class="mt-6 flex flex-wrap gap-3">
                        <a href="{{ route('contact') }}" class="inline-flex rounded-full bg-white px-6 py-3 text-sm font-semibold text-[#7b1248] transition hover:bg-[#ffe7f3]">
                            Contact Us
                        </a>
                        <a href="{{ route('appointments.create') }}" class="inline-flex rounded-full border border-white/45 px-6 py-3 text-sm font-semibold text-white transition hover:bg-white/15">
                            Book a Consultation with Us
                        </a>
                    </div>
                </section>
            </section>
        </main>

        <x-site-footer />
    </div>
</body>
</html>
